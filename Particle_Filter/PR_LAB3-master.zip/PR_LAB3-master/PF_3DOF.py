from math import pi
import numpy as np
import scipy
from IndexStruct import *
from MCLocalization import MCLocalization
from DifferentialDriveSimulatedRobot import *
from Pose3D import *
from ParticleFilter import pdf

class PF_3DOF(MCLocalization):
    def __init__(self, index, kSteps, robot, Map, particles, *args):
        super().__init__(index, kSteps, robot, particles, *args)

        self.dt = 0.1  # dt is the sampling time at which we iterate the DR
        self.wheelRadius = 0.1  # wheel radius
        self.wheelBase = 0.5  # wheel base
        self.robot.pulse_x_wheelTurns = 4096  # number of pulses per wheel turn

        self.M = Map # Save the map for the observation model (Map Based Localization)

    def GetInput(self):
        """
        Get the input for the motion model.

        :return: * **uk, Qk**. uk: input vector (:math:`u_k={}^B[\\Delta L~\\Delta R]^T`), Qk: covariance of the input noise

        **To be completed by the student**.
        """
        zsk, Rsk = self.robot.ReadEncoders()  # Encoder readings
        left_wheel_disp = zsk[0, 0] * (2 * np.pi * self.wheelRadius / self.robot.pulse_x_wheelTurns)
        right_wheel_disp = zsk[1, 0] * (2 * np.pi * self.wheelRadius / self.robot.pulse_x_wheelTurns)
    
        # Input vector uk
        uk = np.array([[left_wheel_disp], [right_wheel_disp]])
    
        # Covariance matrix for input noise
        #Qk = self.robot.Qsk  # Assumed to be provided by the robot class
        QK = np.array([[0.1,0],[0,0.1]])
        return uk, QK
    
    def GetMeasurements(self):
        """ 
        Get the measurements for the observation model.

        :return: * **zf, Rf**. zf: list of measurements, Rf: list of covariance matrices of the measurements

        **To be completed by the student**. 
        """
        zf=self.robot.ReadRanges() #getting range measurements
        Rf= np.diag([0.5]*len(zf)) # covariance for each measuremnets
        return zf,Rf 

    
    def SampleProcessModel(self, particle, uk, Qk):
       """
       Process model of a single particle given an input.
 
       :param particle: a single particle at time k
       :param uk: input variable at time k
       :param Qk: Covariance matrix associated to the input at time k
       :return: the particle state at time k+1, after applying the model
       """
       # Ensure `particle` is a (3, 1) array for x, y, theta
       try:
         x, y, theta = particle[0, 0], particle[1, 0], particle[2, 0]
       except IndexError:
          raise ValueError("Expected particle to be a 3x1 array or Pose3D object")

       # Add noise to control inputs
       noise = np.random.multivariate_normal([0, 0], Qk).reshape(2)
       deltaL, deltaR = uk[0, 0] + noise[0], uk[1, 0] + noise[1]
    
       # Update particle state based on control inputs
       d_center = (deltaL + deltaR) / 2.0
       d_theta = (deltaR - deltaL) / self.wheelBase
       x += d_center * np.cos(theta + d_theta / 2.0)
       y += d_center * np.sin(theta + d_theta / 2.0)
       theta += d_theta

       # Return updated state as new Pose3D object
       return Pose3D(np.array([[x], [y], [theta]]))

    
    def ObservationModel(self, particle, z, R):
        """ 
        Compute the measurement probability of a single particle with respect to a single measurement.
        
        **To be completed by the student**. 
        """
        # Simulated measurements for the particle based on its position
        simulated_measurements = []
        for landmark in self.robot.map_landmarks:
          dx = landmark[0, 0] - particle[0, 0]  # Difference in x-coordinates
          dy = landmark[1, 0] - particle[1, 0]  # Difference in y-coordinates
          simulated_measurements.append(np.sqrt(dx**2 + dy**2))  # Range to the landmark
        return simulated_measurements
        #
        #
        #
    def pdf(self, simulated_measurement, R, z):
       """
       Compute the probability density of the actual measurement given the simulated measurement.

      :param simulated_measurement: Simulated measurement vector for a particle.
      :param R: Measurement noise covariance matrix.
      :param z: Actual measurement vector from the robot's sensors.
      :return: Probability density value for the given measurements.
      """
       return scipy.stats.multivariate_normal.pdf(z, mean=simulated_measurement, cov=R)

if __name__ == '__main__':

    #Feature map landamark
    M = [np.array([[-40, 5]]).T,
           np.array([[-5, 40]]).T,
           np.array([[-5, 25]]).T,
           np.array([[-3, 50]]).T,
           np.array([[-20, 3]]).T,
           np.array([[40,-40]]).T]  # feature map. Position of 2 point features in the world frame.
    

    #Simulation parameters
    xs0 = np.zeros((6, 1)) #initial state of robot
    kSteps = 5000 #number of steps
    index = [IndexStruct("x", 0, None), IndexStruct("y", 1, None), IndexStruct("yaw", 2, 0)]
    print("Instantiating DifferentialDriveSimulatedRobot...")
    robot = DifferentialDriveSimulatedRobot(xs0, M)  # instantiate simulated robot object

    # Initialize  Particle Filter
    x0 = Pose3D(np.zeros((3,1)))  # initial guess robot pose
    P0 = np.diag([1.0, 1.0, np.deg2rad(20)**2]) # Initial uncertainty
    n_particles = 100 # Number of particles, CHOSEN BY THE STUDENT

    # create array of n_particles particles distributed randomly around x0 with covariance P
    #Each particle musy be a Pose3D object!!!

    # TO BE COMPLETED BY THE STUDENT
    print(f"Creating {n_particles} particles...")
    particles = [
    Pose3D(np.random.multivariate_normal([0, 0, 0], P0).reshape((3, 1)))
    for _ in range(n_particles)
    ]
    # output for verification
    print(f"Number of particles: {len(particles)}")
    print(f"Initial particles:\n{particles[:3]}")  # Print first 3 particles for verification
    # particles is a np.array of Pose3D objects
    usk=np.array([[0.5, 0.03]]).T # control input 
    print("Instantiating PF_3DOF...")
    pf = PF_3DOF(index, kSteps, robot, M, particles) #Initialazation of particle filter
     # Start localization loop
    print("Starting Localization Loop...")
    pf.LocalizationLoop(x0, usk) # running Localization loop
    print("Localization completed. Exiting.")
    exit(0)
