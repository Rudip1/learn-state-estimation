import numpy as np
import matplotlib.pyplot as plt
import math
import random
from Pose3D import Pose3D

def pdf(mean, sigma, x):
    """Compute the PDF for a normal distribution."""
    return 1 / (sigma * math.sqrt(2 * math.pi)) * math.exp(- (x-mean)**2 / (2 * sigma**2))


class ParticleFilter:
    """
    Particle Filter Localization.

    This class implements basic plotting and logging functionality for the Particle Filter,
    as well as the interface for the child classes to implement.

    A particle filter is a Monte Carlo algorithm that approximates the posterior distribution of the robot
    by a set of weighted particles.  Note that the "weight" (which is a terrible term) is simply the 
    probability of the particle being correct. Therefore, each particle is an estimate, and each estimate 
    has some probability of being correct.

    """
    def __init__(self, particles,resampling_function=None, resampling_threshold=10 ,*args):
        """
        Constructor of the Particle Filter class.

        :param index: Logging index structure (:class:`Index`)
        :param kSteps: Number of time steps to simulate
        :param robot: Simulation robot object (:class:`Robot`)
        :param particles: initial particles as a list of Pose objects (or at least a list of numpy arrays)
        :param args: Rest of arguments to be passed to the parent constructor
        """
         # Prompt user if resampling function is not provided
        if resampling_function is None:
            print("Select a resampling method:")
            print("1. Roulette Wheel Resampling")
            print("2. Stochastic Universal Resampling")
            choice = input("Enter your choice (1 or 2): ").strip()
            if choice == "1":
                resampling_function = "roulette"
            elif choice == "2":
                resampling_function = "sus"
            else:
                raise ValueError("Invalid choice! Please select '1' or '2'.")

        # Map resampling method names to functions
        resampling_methods = {
            "roulette": self.RouletteWheelResampling,
            "sus": self.StochasticUniversalResampling,
        }
        
        # Set resampling function
        if resampling_function in resampling_methods:
            self.resampling_function = resampling_methods[resampling_function]
        else:
            raise ValueError(f"Unknown resampling method: {resampling_function}")
        
        # Initialize particles and weights
        self.particles = particles
        self.particle_weights = np.ones(len(particles)) / len(particles)  # Evenly distributed weights
        
        # Resampling threshold
        self.resampling_threshold = resampling_threshold
        #self.particles = particles
        #self.particle_weights = np.ones(len(particles)) / len(particles) # evenly distributed weights
        #self.resampling_function = self.StochasticUniversalResampling # choose resampling method
      
     #   self.resampling_threshold = 10 # choose a resampling threshold


    def SampleProcessModel(self, p, u, Q):
        """
        Process model of a single particle given an input
        
        :param p: a single particle at time k
        :param u: input variable at time k
        :param Q: Covariance matrix associated to the input at time k

        :return the particle state at time k+1, after apllying the model
        """
        
      #  print("SampleProcessModel must be implemented in a child class")
       # pass
    
    def ObservationModel(self, p, z, R):
        """
        Compute the measurement probability of a single particle with respect to a single measurement.

        :param p: a single particle
        :param z: a single measurement
        :param R: the covariance matrix associated to z

        :return: the measurement probability (or weight) of the particle p measuring z
        """
        print("ObservationModel must be implemented in a child class")
        pass


    def Prediction(self, u, Q):
        """
        Predict the next state of the system based on a given motion model.

        This function updates the state of each particle by predicting its next state using a motion model.

        :param u: input vector
        :param Q: the covariance matrix associated with the input vector
        :return: None

        **To be completed by the student**
        """

        # For each particle
        # --- Apply the process model to the particle

            # Looping through each particle
        for i in range(len(self.particles)):
         # Applying process model to each particle
           self.particles[i] = self.SampleProcessModel(self.particles[i], u, Q)


    def Update(self, z, R):    
        """
        Update the particle weights based on sensor measurements and perform resampling.

        This function adjusts the weights of particles based on how well they match the sensor measurements.
       
        The updated weights reflect the likelihood of each particle being the true state of the system given
        the sensor measurements.

        The resulting weights must be normalized

        After updating the weights, the function may perform resampling to ensure that particles with higher
        weights are more likely to be selected, maintaining diversity and preventing particle degeneracy.
        
        :param z: measurement vector
        :param R: the covariance matrix associated with the measurement vector

        :return: None

        **To be completed by the student**
        """
        #update weights based on measurements
        for i, particle in enumerate(self.particles):
            simulated_measurement = self.ObservationModel(particle, z, R)
            self.particle_weights[i] = self.pdf(simulated_measurement, R, z)
    
         # Normalize weights
        self.particle_weights /= np.sum(self.particle_weights)

         #resampling if effective number of particles is below the threshold
        n_eff = 1.0 / np.sum(self.particle_weights**2)
        if n_eff < self.resampling_threshold:
         self.resampling_function()
    """  for i in range(len(self.particles)):
          self.particle_weights[i] = self.ObservationModel(self.particles[i], z, R)

        # Normalize weights
        self.particle_weights /= np.sum(self.particle_weights)

        # Resample if necessary
        # n_eff = ...
        n_eff = 1.0 / np.sum(np.square(self.particle_weights))
        if n_eff < self.resampling_threshold:
           self.Resample() """


    def Resample(self) -> None:
        """
        Resample the particles based on their weights to ensure diversity and prevent particle degeneracy.

        This function implements the resampling step of a particle filter algorithm. It uses the weights
        assigned to each particle to determine their likelihood of being selected. Particles with higher weights
        are more likely to be selected, while those with lower weights have a lower chance.

        The resampling process helps to maintain a diverse set of particles that better represents the underlying
        probability distribution of the system state. 

        After resampling, the attributes 'particles' and 'weights' of the ParticleFilter instance are updated
        to reflect the new set of particles and their corresponding weights.

        This method calls the resampling function set as default, mainly either RouletteWheelResampling or StochasticUniversalResampling
       
        :return: None
        """
        return self.resampling_function()
    
    # Resampling methods

    def RouletteWheelResampling(self):
        ''' This method is the Roulette Wheel version of resampling'''

        '''**To be completed by the student**'''

        cumulative_sum = np.cumsum(self.particle_weights)
        cumulative_sum[-1] = 1.0  # Ensure the last value is exactly 1.0 for numerical stability
        new_particles = []
        #selected_indices = []

        for _ in range(len(self.particles)):
            pick = np.random.rand()
            index = np.searchsorted(cumulative_sum, pick)  # Binary search for efficiency
            new_particles.append(self.particles[index])
            #selected_indices.append(index)  # Append the actual selected index

       # print("Roulette selected indices:", selected_indices)  # Log the actual selected indices
        self.particles = new_particles

    def StochasticUniversalResampling(self):
        ''' This method is the Stochastic Universal version of resampling'''
        '''**To be completed by the student**'''
        N = len(self.particles)
        new_particles = []
        step = 1.0 / N
        start = np.random.uniform(0, step)  # Random starting point
        cumulative_sum = np.cumsum(self.particle_weights)
        cumulative_sum[-1] = 1.0  # Numerical stability
        index = 0
        #selected_indices = []  # For debugging

        for threshold in np.arange(start, 1, step):
            while index < N - 1 and cumulative_sum[index] < threshold:
                index += 1
            new_particles.append(self.particles[index])
            #selected_indices.append(index)  # Log selected index

        #print(f"SUS selected indices: {selected_indices}")  # Debugging log
        self.particles = new_particles

    def get_mean_particle(self):
        """
        Calculate the mean particle based on the current set of particles and their weights.
        :return: mean particle
        """
        # Weighted mean
        return np.average(self.particles, axis=0, weights=self.particle_weights)
    
    def get_best_particle(self):
        """
        Calculate the best particle based on the current set of particles and their weights.
        :return: best particle
        """
        # Maximum weight
        return self.particles[np.argmax(self.particle_weights)]

