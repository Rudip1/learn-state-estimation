from Localization import *
import numpy as np
from math import pi,cos,sin
class DR_3DOFDifferentialDrive(Localization):
    """
    Dead Reckoning Localization for a Differential Drive Mobile Robot.
    """
    def __init__(self, index, kSteps, robot, x0,noise_std=(0.005, 0.005, 0.005), *args):
        """
        Constructor of the :class:`prlab.DR_3DOFDifferentialDrive` class.

        :param args: Rest of arguments to be passed to the parent constructor
        """

        super().__init__(index, kSteps, robot, x0, *args)  # call parent constructor

        self.dt = 0.1  # dt is the sampling time at which we iterate the DR
        self.t_1 = 0.0  # t_1 is the previous time at which we iterated the DR
        self.wheelRadius = 0.1  # wheel radius
        self.wheelBase = 0.5  # wheel base
        self.robot.pulse_x_wheelTurns = 4096  # number of pulses per wheel turn
        
        # Standard deviations for noise
        self.std_x, self.std_y, self.std_heading = noise_std

    def Localize(self, xk_1, uk):  # motion model
        """
        Motion model for the 3DOF (:math:`x_k=[x_{k}~y_{k}~\psi_{k}]^T`) Differential Drive Mobile robot using as input the readings of the wheel encoders (:math:`u_k=[n_L~n_R]^T`).
        :parameter xk_1: previous robot pose estimate (:math:`x_{k-1}=[x_{k-1}~y_{k-1}~\psi_{k-1}]^T`)
        :parameter uk: input vector (:math:`u_k=[u_{k}~v_{k}~w_{k}~r_{k}]^T`)
        :return xk: current robot pose estimate (:math:`x_k=[x_{k}~y_{k}~\psi_{k}]^T`)
        """  

        # TODO: to be completed by the student
         # Store previous state and input for Logging purposes
        self.etak_1 = xk_1  # store previous state
        self.uk = uk  # store input
        
        N_L = uk[0,0] # Number of Left wheel pulse
        N_R = uk[1,0] # Number Right  wheel pulse
        dl = (N_L*2*pi*self.wheelRadius)/  (self.robot.pulse_x_wheelTurns ) # Left wheel distance 
        dr = (N_R*2*pi*self.wheelRadius)/ (self.robot.pulse_x_wheelTurns )  # Right wheel distance 
        
        #Distance by the midpoint of the wheels
        d = (dl + dr )/2      
        
        #heading change
        delata_teta = (dr-dl)/(self.wheelBase) 
        teta_k = delata_teta + xk_1[2][0]
        
        xk = [[(xk_1[0][0] + d*cos(teta_k))+ np.random.normal(0, self.std_x)] , #update x position
            [(xk_1[1][0]+d*sin(teta_k)) + np.random.normal(0, self.std_y)] , #update y position
            [teta_k+np.random.normal(0, self.std_heading)]] # update heading 
        return xk

    def GetInput(self):
        """
        Get the input for the motion model. In this case, the input is the readings from both wheel encoders.

        :return: uk:  input vector (:math:`u_k=[n_L~n_R]^T`)
        """

        # TODO: to be completed by the student
        
        uk = self.robot.ReadEncoders()[0]
        return uk
    
    

